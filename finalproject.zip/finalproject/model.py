import pandas as pd
from nltk.sentiment import SentimentIntensityAnalyzer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation

# Load the feedback data from CSV
feedback_data = pd.read_csv('C:/Users/sagar moti chaurasia/Downloads/project/finalproject/feedback_data.csv')

# Preprocess the feedback text (assuming it's already cleaned)-
feedback_text = feedback_data['feedback']

# Sentiment Analysis
sia = SentimentIntensityAnalyzer()
feedback_data['sentiment_score'] = feedback_text.apply(lambda x: sia.polarity_scores(x)['compound'])

# Topic Modeling
vectorizer = CountVectorizer(max_features=1000, stop_words='english') 
X = vectorizer.fit_transform(feedback_text)

lda = LatentDirichletAllocation(n_components=5, random_state=42)
lda.fit(X)

# Display the top words for each topic
def display_topics(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):
        print(f"Topic {topic_idx+1}:")
        print(" ".join([feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]]))
        print()

print("Top words for each topic:")
display_topics(lda, vectorizer.get_feature_names_out(), 10)

# Add topic labels to the feedback data
topic_labels = lda.transform(X)
feedback_data['topic'] = topic_labels.argmax(axis=1) + 1

# Define thresholds for positive, negative, and neutral sentiments
threshold_pos = 0.2
threshold_neg = -0.2

# Classify feedback based on sentiment scores
feedback_data['sentiment'] = feedback_data['sentiment_score'].apply(lambda x: 'positive' if x >= threshold_pos else ('negative' if x <= threshold_neg else 'neutral'))

# Save the updated feedback data
feedback_data.to_csv('processed_feedback_data.csv', index=False)