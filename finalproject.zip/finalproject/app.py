from flask import Flask, render_template
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

app = Flask(__name__)

@app.route('/')
def index():
    # Load the processed feedback data
    feedback_data = pd.read_csv('processed_feedback_data.csv')

    # Feedback Sentiment Distribution
    plt.figure(figsize=(8, 6))
    sns.countplot(x='sentiment', data=feedback_data, palette='viridis')
    plt.title('Sentiment Distribution of Feedback')
    plt.xlabel('Sentiment')
    plt.ylabel('Count')
    sentiment_img = io.BytesIO()
    plt.savefig(sentiment_img, format='png')
    sentiment_img.seek(0)
    sentiment_plot = base64.b64encode(sentiment_img.getvalue()).decode('utf8')

    # Feedback Topic Distribution
    plt.figure(figsize=(10, 8))
    sns.countplot(x='topic', data=feedback_data, palette='muted')
    plt.title('Topic Distribution of Feedback')
    plt.xlabel('Topic')
    plt.ylabel('Count')
    topic_img = io.BytesIO()
    plt.savefig(topic_img, format='png')
    topic_img.seek(0)
    topic_plot = base64.b64encode(topic_img.getvalue()).decode('utf8')

    return render_template('index.html', sentiment_plot=sentiment_plot, topic_plot=topic_plot)

if __name__ == '_main_':
    app.run(debug=True)