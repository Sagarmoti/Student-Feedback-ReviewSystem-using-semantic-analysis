import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the processed feedback data
feedback_data = pd.read_csv('processed_feedback_data.csv')

# Feedback Sentiment Distribution
plt.figure(figsize=(8, 6))
sns.countplot(x='sentiment', data=feedback_data, palette='viridis')
plt.title('Sentiment Distribution of Feedback')
plt.xlabel('Sentiment')
plt.ylabel('Count')
plt.show()

# Feedback Topic Distribution
plt.figure(figsize=(10, 8))
sns.countplot(x='topic', data=feedback_data, palette='muted')
plt.title('Topic Distribution of Feedback')
plt.xlabel('Topic')
plt.ylabel('Count')
plt.show()